from django.apps import AppConfig


class PagyConfig(AppConfig):
    name = 'pagy'
